library(editrules)

df=read.csv("C:/Users/sagar/Downloads/DM_Practicals/DM_Practicals/Editrules/people.txt")

r=editfile("C:/Users/sagar/Downloads/DM_Practicals/DM_Practicals/Editrules/r1.txt")

ve=violatedEdits(r,df)
summary(ve)
plot(ve)


